import{v as t,x as d}from"./entry.client-DC94RlXZ.js";import"./vendor-43TFuiWl.js";export{t as ErrorBoundary,d as default};
//# sourceMappingURL=root-CfgK_qbt.js.map
